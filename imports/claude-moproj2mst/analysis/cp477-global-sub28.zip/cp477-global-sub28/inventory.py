"""CP477 read-only offline exact-displacement inventory. No target execution."""
import pathlib,struct,hashlib,json,re,subprocess,bisect,time,collections
root=pathlib.Path(r'C:\Users\alext\Projects\codex-deform-rea\imports\claude-moproj2mst')
out=pathlib.Path(__file__).resolve().parent
p=root/'evidence/original-binaries/DEF_GUI_MO_64.exe'; b=p.read_bytes(); h=struct.unpack_from('<I',b,60)[0]; o=h+24; base=struct.unpack_from('<Q',b,o+24)[0]; sh=o+struct.unpack_from('<H',b,h+20)[0]
sections=[]
for i in range(struct.unpack_from('<H',b,h+6)[0]):
 q=sh+40*i; vs,rva,rs,rp=struct.unpack_from('<IIII',b,q+8); flags=struct.unpack_from('<I',b,q+36)[0]
 sections.append(dict(name=b[q:q+8].rstrip(b'\0').decode(),vs=vs,rva=rva,rs=rs,rp=rp,flags=flags))
def off(a):
 r=a-base
 for s in sections:
  if s['rva']<=r<s['rva']+s['rs']: return s['rp']+r-s['rva']
 raise ValueError(hex(a))
er,esz=struct.unpack_from('<II',b,o+112+24); eoff=off(base+er)
funcs=[(base+a,base+z,base+u) for a,z,u in struct.iter_unpack('<III',b[eoff:eoff+esz])]; starts=[x[0] for x in funcs]
def func(a):
 i=bisect.bisect_right(starts,a)-1
 return funcs[i][:2] if i>=0 and a<funcs[i][1] else None
getter_calls=[0x140090337,0x1400916f6,0x14009a0f8,0x14013d798,0x14013ed31]
excluded_functions=[func(a) for a in getter_calls]+[(0x1400b5470,0x1400b566c),(0x1400b5680,0x1400b58c6),(0x1400ba800,0x1400bb27f)]
tool=r'C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Tools\MSVC\14.44.35207\bin\Hostx64\x64\dumpbin.exe'
pat=re.compile(r'^  ([0-9A-F]{16}): ([0-9A-F ]+?)(?: {2,}(\S+)\s*(.*))?$')
cont=re.compile(r'^\s{12,}((?:[0-9A-F]{2} ?)+)\s*$')
mem=re.compile(r'\[([^\]]*\+0*28h)\]',re.I)
sites=[];stats=[];contexts={};recent=collections.deque(maxlen=16);pending=[];t=time.time()
for s in sections:
 if not s['flags']&0x20000000:continue
 start=base+s['rva'];end=start+s['vs']
 proc=subprocess.Popen([tool,'/disasm',f'/range:{start:#x},{end-1:#x}',str(p)],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,encoding='utf-8',errors='replace')
 st=dict(name=s['name'],start=hex(start),end=hex(end),bytes=end-start,instructions=0,decoded_bytes=0,byte_mismatches=0,gaps=[],invalid=0,site_count=0,stdout_lines=0)
 cur=None;last=start;stdout_hash=hashlib.sha256()
 def finish(c):
  global last
  if c is None:return
  a,bb,mn,ops=c;n=len(bb);st['instructions']+=1;st['decoded_bytes']+=n
  if bytes(bb)!=b[off(a):off(a)+n]:st['byte_mismatches']+=1
  if a!=last and len(st['gaps'])<100:st['gaps'].append([hex(last),hex(a)])
  last=a+n
  if mn in ('???','db'):st['invalid']+=1
  text=f'{a:#x}: {mn} {ops}'
  for ent in pending[:]:
   ent['after'].append(text)
   if len(ent['after'])>=16:pending.remove(ent)
  mm=mem.findall(ops)
  if mm and mn!='lea':
   expr=mm[0];regs=re.findall(r'\b(?:r[a-z0-9]+|e[a-z0-9]+)\b',expr);stack=bool(re.search(r'\b(?:rsp|esp)\b',expr));operands=[x.strip() for x in ops.split(',')]
   kind=('store' if '[' in operands[0] else 'load') if mn.startswith(('mov','vmov')) else 'other_memory'
   f=func(a)
   ent=dict(va=hex(a),bytes=bytes(bb).hex(),mnemonic=mn,operands=ops,expression=expr,registers=regs,rsp_relative=stack,kind=kind,function=[hex(x) for x in f] if f else None,known_excluded_family=f in excluded_functions or a==0x1400b5aba)
   sites.append(ent);st['site_count']+=1
   if not stack:
    ctx=dict(before=list(recent),site=text,after=[]);contexts[hex(a)]=ctx;pending.append(ctx)
  recent.append(text)
 for line in proc.stdout:
  st['stdout_lines']+=1;stdout_hash.update(line.encode());m=pat.match(line.rstrip('\n'))
  if m:finish(cur);cur=[int(m[1],16),bytearray.fromhex(m[2]),m[3] or '',m[4] or '']
  elif cur:
   m=cont.match(line.rstrip('\n'))
   if m:cur[1].extend(bytes.fromhex(m[1]))
 finish(cur);st['exit_code']=proc.wait();st['stderr']=proc.stderr.read()[:1000];st['last_end']=hex(last);st['stdout_sha256']=stdout_hash.hexdigest();stats.append(st)
 print(json.dumps({'progress':s['name'],'instructions':st['instructions'],'sites':st['site_count'],'elapsed_seconds':round(time.time()-t,2)}),flush=True)
ns=[x for x in sites if not x['rsp_relative']];outside=[x for x in ns if not x['known_excluded_family']]
totals=dict(sites=len(sites),rsp_relative=sum(x['rsp_relative'] for x in sites),non_rsp=len(ns),non_rsp_kinds=dict(collections.Counter(x['kind'] for x in ns)),outside_known_families=len(outside),outside_mov_qword=sum(x['kind'] in ('load','store') and 'qword ptr' in x['operands'] for x in outside),rbp_relative=sum(bool(re.search(r'\b(?:rbp|ebp)\b',x['expression'])) for x in ns))
report=dict(binary=str(p),binary_sha256=hashlib.sha256(b).hexdigest(),binary_bytes=len(b),method='MSVC dumpbin linear sweep; every IMAGE_SCN_MEM_EXECUTE virtual range requested; +0*28h memory displacement exact incl zero padding; lea excluded; instruction bytes verified via PE raw mapping; RSP explicit, RBP unknown; .pdata containment only, no type provenance',tool=tool,sections=stats,elapsed_seconds=round(time.time()-t,2),known_getter_call_sites=[hex(x) for x in getter_calls],excluded_functions=[[hex(x) for x in f] for f in excluded_functions],totals=totals,sites=sites)
(out/'inventory.json').write_text(json.dumps(report,indent=2));(out/'contexts.json').write_text(json.dumps(contexts,indent=2))
print(json.dumps({'output':str(out),'totals':totals,'sections':stats,'elapsed_seconds':report['elapsed_seconds']}),flush=True)

